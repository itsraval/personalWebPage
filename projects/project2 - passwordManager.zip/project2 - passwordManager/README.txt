Click on Password Manager to run the application.

Require java to run the program.

DO NOT delete the folder "files".

www.alessandro.ravizzotti.tk

This program is made by Alessandro Ravizzotti.
Copyright © 2020