Click on Password Manager.vbs to run the application.

Require JAVA to run the program.
Require javafx-sdk-11.0.2 in this folder.

DO NOT delete the folder "files".

www.alessandro.ravizzotti.tk

This program is made by Alessandro Ravizzotti.
Copyright © 2020