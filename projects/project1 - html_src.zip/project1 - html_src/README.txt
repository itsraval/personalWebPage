Click on Html Update to run the application.

Require python to run the program.

DO NOT delete the folder "files".

www.alessandro.ravizzotti.tk

This program is made by Alessandro Ravizzotti.
Copyright © 2020