Folder where html will be created and then deleted.
Html will be converted into PDF.