To run the server required 
Nodejs
Express
Puppeteer
you need to ad node_modules folder

and wkthtltopdf.exe installed and as environment variable

www.alessandro.ravizzotti.tk

This program is made by Alessandro Ravizzotti.
Copyright © 2021