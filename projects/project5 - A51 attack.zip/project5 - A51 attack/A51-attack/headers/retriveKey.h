#ifndef retriveKey
#define retriveKey

void reverse100Clock(State s, int* frame);

#endif