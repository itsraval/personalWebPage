#define R1LENGTH 19
#define R2LENGTH 22
#define R3LENGTH 23

#define R1MAJ 8
#define R2MAJ 10
#define R3MAJ 10

#define R1XORR2LENGTH 11

#define KEYLENGTH 64
#define FRAMELENGTH 22
#define OUTPUTLENGTH 114