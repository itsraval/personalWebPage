The program is written in C.
If you are running it on Windows you can use the .bat file.

www.alessandro.ravizzotti.tk

This program is made by Alessandro Ravizzotti.
Copyright © 2022